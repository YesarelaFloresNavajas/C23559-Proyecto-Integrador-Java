package com.codoacodo.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.codoacodo.dao.OradorDAO2;
import com.codoacodo.dto.Orador;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/api/ListadoControllerOrador")
public class ListadoControllerOrador extends HttpServlet {
    
    //este es el metodo...
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//crear la instancia de ProductoDAO
		OradorDAO2 dao = new OradorDAO2();
                
		// List<Orador>listado=new ArrayList();
		//invocar al metodo listarProductos()
		List<Orador> listado = null;
        try {
            listado = dao.selectOradores();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
                
		//grabar el listado en el request para que lo vea la siguiente pagina
		req.setAttribute("listado", listado);
		
		//ir a la siguiente pagina
		getServletContext().getRequestDispatcher("/listadoOradores.jsp").forward(req, resp);
	}
}
