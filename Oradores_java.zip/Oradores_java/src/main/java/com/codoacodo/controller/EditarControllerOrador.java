package com.codoacodo.controller;

import com.codoacodo.dao.OradorDAO2;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.codoacodo.dto.Orador;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

//import java.sql.Timestamp;


@WebServlet("/api/EditarControllerOrador")
public class EditarControllerOrador extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
               
                String id= req.getParameter("id");
                //Crear un orador DAO2
                OradorDAO2 dao = new OradorDAO2();
                
                Orador ora = null;
            try {
                //invocar el metodo obtenerPorId(id)
                ora = dao.obtenerPorId(Long.valueOf(id));
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
                //guardar en el request
                req.setAttribute("orador", ora);
                //ir a la siguiente pagina
		getServletContext().getRequestDispatcher("/editarOrador.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
            try {
                String id =req.getParameter("Id");
                String nombre = req.getParameter("nombre");
                String apellido = req.getParameter("apellido");
                String mail = req.getParameter("mail");
                String tema = req.getParameter("tema");
                String fechaAlta = req.getParameter("fechaAlta");
                
                //Crear OradorDAO2
                OradorDAO2 dao = new OradorDAO2();
                //invocar modificarOrador(params)
                dao.modificarOrador(nombre, apellido, mail, tema);
                
                //ir a la siguiente pagina
                resp.sendRedirect(req.getContextPath()+"/api/ListadoControllerOrador");
                
                //resp.sendRedirect(req.getContextPath()+"/index.jsp");
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(EditarControllerOrador.class.getName()).log(Level.SEVERE, null, ex);
            }
                

	}
}

