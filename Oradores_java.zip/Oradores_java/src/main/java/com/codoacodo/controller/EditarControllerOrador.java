package com.codoacodo.controller;

import com.codoacodo.dao.OradorDAO2;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.codoacodo.dto.Orador;
import static java.lang.Integer.parseInt;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

//import java.sql.Timestamp;


@WebServlet("/api/EditarControllerOrador")
public class EditarControllerOrador extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
               
            try {
                String id= req.getParameter("id");
                //Crear un orador DAO2
                OradorDAO2 dao = new OradorDAO2();
                
                //invocar el metodo obtenerPorId(id)
                Orador oradorDB = dao.obtenerPorId(Long.valueOf(id));
                //guardar en el request el producto
                req.setAttribute("orador", oradorDB);
                
                //ir a la siguiente pagina
                getServletContext().getRequestDispatcher("/editarOrador.jsp").forward(req, resp);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(EditarControllerOrador.class.getName()).log(Level.SEVERE, null, ex);
            }
                
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                String id = req.getParameter("id");
		String nombre = req.getParameter("nombre");
		String apellido = req.getParameter("apellido");
		String mail = req.getParameter("mail");
		String tema = req.getParameter("tema");
                

		
		//Crear OradorDAO
		OradorDAO2 dao = new OradorDAO2();
                
		Orador oraActualizado = new Orador(Long.valueOf(id),nombre, apellido, mail, tema);
            try {
                dao.actualizarOrador(oraActualizado);
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(EditarControllerOrador.class.getName()).log(Level.SEVERE, null, ex);
            }

		//ir a la siguiente pagina
		resp.sendRedirect(req.getContextPath()+"/api/ListadoControllerOrador");
                

	}
}

