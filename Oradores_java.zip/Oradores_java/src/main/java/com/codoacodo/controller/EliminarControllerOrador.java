package com.codoacodo.controller;

import com.codoacodo.dao.OradorDAO2;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/api/EliminarControllerOrador")
public class EliminarControllerOrador extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
                
                String id= req.getParameter("id");
                
                OradorDAO2 dao = new OradorDAO2();
                
            try {
                dao.eliminarOrador(Long.valueOf(id));
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
                
                resp.sendRedirect(req.getContextPath()+"/api/ListadoControllerOrador");
		
	}
	
	
}

