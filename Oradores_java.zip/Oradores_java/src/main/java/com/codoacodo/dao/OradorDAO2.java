
package com.codoacodo.dao;
import com.codoacodo.connection.Conexion2;
import static com.codoacodo.connection.Conexion2.*;
import com.codoacodo.dto.Orador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Timestamp;


public class OradorDAO2 {
    //atributos
     private static final String SQL_SELECT = "SELECT * FROM oradores";
     private static final String SQL_INSERT = "INSERT INTO oradores(nombre, apellido, mail, tema) VALUES (?, ?, ?, ?)";
     private static final String SQL_UPDATE = "UPDATE oradores SET nombre=?, apellido=?, mail=?, tema=? WHERE id_orador=?";
     private static final String SQL_DELETE = "DELETE FROM oradores WHERE id_orador = ?";
     private static final String SQL_BUSCAR_ID = "SELECT * FROM ORADORES WHERE id_orador= ?";
     //metodo listar
      public List<Orador> selectOradores() throws ClassNotFoundException {
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        Orador orador = null;
        List<Orador> oradores = new ArrayList();
        
        
        try {
            conn = getConexion();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL_SELECT);
            //Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            while(rs.next()) {
                Long idOrador = rs.getLong(1);
                String nombre = rs.getString(2);
                String apellido = rs.getString(3);
                String mail = rs.getString(4);
                String tema = rs.getString(5);
                Timestamp fechaAlta = rs.getTimestamp(6);
                
                //----public Orador(long i, String n, String a , String t)
                orador = new Orador(idOrador, nombre, apellido,mail, tema, fechaAlta);
                oradores.add(orador);
            }
            /*
        } catch(SQLException | NullPointerException | ClassNotFoundException |
                InstantiationException | IllegalAccessException ex) {
            */
            } catch(SQLException ex) {
                ex.printStackTrace(System.out);
                ex.getMessage();
            
            } finally {
                try {
                    close(rs);
                    close(stmt);
                    close(conn);
                } catch(SQLException ex) {
                    ex.printStackTrace();
            }
        }
        return oradores;
    }
    //agregar Orador
      public int insertarOrador(Orador orador) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, orador.getNombre());
            stmt.setString(2, orador.getApellido());
            stmt.setString(3, orador.getMail());
            stmt.setString(4, orador.getTema());
                       
            registros = stmt.executeUpdate();
        } catch(SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
           try{
               close(stmt);
               close(conn);
           } catch (SQLException ex) {
               ex.getMessage();
           }
        }
        return registros;
    }
      
    //editar Orador
    public int actualizarOrador(Orador ora) throws ClassNotFoundException, SQLException {
        Connection con = getConexion();
        PreparedStatement stmt = null;
        int registros = 0;
        
        try{

            stmt = con.prepareStatement(SQL_UPDATE);

            stmt.setString(1, ora.getNombre());
            stmt.setString(2, ora.getApellido());
            stmt.setString(3, ora.getMail());
            stmt.setString(4, ora.getTema());
            stmt.setLong(5, ora.getId());
            registros = stmt.executeUpdate();
        } catch(SQLException | NullPointerException ex) {
                ex.printStackTrace(System.out);          
        } finally {
            try {
                con.close();
                stmt.close();
            } catch(SQLException | NullPointerException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    	public int modificarOrador (int id, String nombre, String apellido, String mail, String tema) throws SQLException, ClassNotFoundException {
		Connection con = Conexion2.getConexion();
                int registros = 0;
		if(con != null) { 
			String sql = SQL_UPDATE;
                    Statement st = con.createStatement();	
                    registros = st.executeUpdate(sql);
		
			try {
                        	con.close();
                        }catch (SQLException e) {
				e.printStackTrace();
			}
		}
         return registros;
	}
        
    	public int editarOrador(String nombre, String apellido, String mail, String tema) throws SQLException, ClassNotFoundException {
		Connection con = Conexion2.getConexion();
                int registros = 0;
		if(con != null) { 
			String sql = "UPDATE orador WHERE id_orador= ?"
					+ " set nombre='"+nombre+"',"
					+ " apellido='"+apellido+"',"
					+ " mail='"+ mail +"'"
                                        + " tema='"+ tema +"'";		
		
			try {
				Statement st = con.createStatement();			
				st.executeUpdate(sql);
				con.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
         return registros;
	}
    
    public int eliminarOrador(Long id) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        
        try{
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setLong(1, id);
            registros = stmt.executeUpdate();
        }  catch(SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                close(stmt);
                close(conn);
            } catch(SQLException | NullPointerException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    
    public Orador obtenerPorId(Long id) throws ClassNotFoundException {            
        Connection conn = null;
        PreparedStatement stmt = null;
        Orador oradorDB = null;
		//Statement
	try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_BUSCAR_ID);
            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();        
		
            //VIENE UN SOLO REGISTRO!!!
			
            if(rs.next()) {//si existe, hay uno solo
				// rs > sacando los datos
                Long idOrador = rs.getLong(1);
                String nombre = rs.getString(2);
                String apellido = rs.getString(3);
                String mail = rs.getString(4);
                String tema = rs.getString(5);
                Timestamp fechaAlta = rs.getTimestamp(6);
                
                //----public Orador(long i, String n, String a , String t, LocalDate ld)
                oradorDB = new Orador(idOrador, nombre, apellido,mail, tema, fechaAlta);
			}			
		} catch (SQLException ex) {
			// ERRORES
			ex.printStackTrace();
		} finally {
                    try {
                        close(stmt);
                        close(conn);
                    } catch(SQLException ex) {
                        ex.printStackTrace();
                    }
                }
		return oradorDB;
	}
    
    
     //prueba de buscador
    public List<Orador> buscar(String clave, String campo) throws ClassNotFoundException {
        String sql;
            if("nombre".equals(campo)){
                sql = "SELECT * FROM ORADORES WHERE nombre LIKE '%"+clave+"%' ";
            }else{
                if("apellido".equals(campo)){
                    sql = "SELECT * FROM ORADORES WHERE apellido LIKE '%"+clave+"%' ";
                }else{
                    sql = "SELECT * FROM ORADORES WHERE tema LIKE '%"+clave+"%' ";
                }
            } 
                 
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null; 
		
                
               //String sql = "SELECT * FROM ORADORES WHERE apellido LIKE '%"+clave+"%' ";
		//Connection
		//Connection con = getConexion();
        List<Orador> listado = new ArrayList();
		//Statement
	try {
            conn = getConexion();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql); 
			//Statement st = con.createStatement();
			
			//resultset
			//ResultSet rs = st.executeQuery(sql);
                        
            while(rs.next()) {
                Long idOrador = rs.getLong(1);
                String nombre = rs.getString(2);
                String apellido = rs.getString(3);
                String mail = rs.getString(4);
                String tema = rs.getString(5);
                Timestamp fechaAlta = rs.getTimestamp(6);
                
                        //----public Orador(long i, String n, String a , String t, LocalDate ld)
                Orador orador = new Orador(idOrador, nombre, apellido,mail, tema, fechaAlta);
                listado.add(orador);
				
			}//while	
            } catch (SQLException e) {
			// ERRORES
                e.printStackTrace();
            } finally {
                try {
                    close(rs);
                    close(stmt);
                    close(conn);
                } catch(SQLException ex) {
                    ex.printStackTrace();
                }
            }		
            return listado;
	}
}
