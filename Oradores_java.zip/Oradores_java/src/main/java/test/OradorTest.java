
package test;
import com.codoacodo.dto.Orador;
import java.util.ArrayList;
import java.util.List;
import com.codoacodo.dao.OradorDAO2;
import java.sql.SQLException;
import java.util.Iterator;

public class OradorTest {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        
        List<Orador>oradores=new ArrayList();
        
        OradorDAO2 dao = new OradorDAO2();
        
        oradores=dao.selectOradores();//mostrar datos 
       //oradores.forEach(System.out::println);
        Iterator<Orador> it = oradores.iterator();
        
        while(it.hasNext()){
            System.out.println(it.next());
        }
        for( Orador  unProducto : oradores) {
            System.out.println(unProducto.getApellido());
        }
        
        Orador unOrador = dao.obtenerPorId(Long.valueOf("4"));
        
        System.out.println(unOrador);
        
    }
}