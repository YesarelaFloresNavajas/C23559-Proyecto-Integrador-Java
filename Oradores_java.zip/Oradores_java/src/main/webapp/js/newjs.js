
let nombre = document.getElementById('txtnombre');
let errorNombre = document.getElementById('errorNombre');
let apellido = document.getElementById('txtapellido');
let errorApellido = document.getElementById('errorApellido');
let mail = document.getElementById('txtmail');
let errorMail = document.getElementById('errorMail');
let tema = document.getElementById('txttema');
let errorTema = document.getElementById('errorTema');

//función para quitar el estilo de error a los elementos del formulario
const quitarClError = () => {
  let elemento = document.querySelectorAll(".form-control");
  for (let i = 0; i < elemento.length; i++) {
      elemento[i].classList.remove('is-invalid');
  }
  let elementoinv = document.querySelectorAll(".invalid-feedback");
  for (let i = 0; i < elementoinv.length; i++) {
      elementoinv[i].classList.remove('own');
  }
};


//Validar el formulario
const validarForm = () => {
  
//ejecuto la función para que quite los estilos de error en los campos que lo tienen
  quitarClError();


  const nombreVálido = nombre => {
    return /^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/.test(nombre);
    };

if (!nombreVálido(nombre.value)) {
    nombre.classList.add('is-invalid');
    errorNombre.classList.add('own');
    //la clase pone un div enn display:block, ya que tiene la class="invalid-feedback "
    nombre.focus();
    return;
};

const apellidoVálido = apellido => {
    return /^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/.test(apellido);
};

if (!apellidoVálido(apellido.value)) {
    apellido.classList.add('is-invalid');
    errorApellido.classList.add('own');
    apellido.focus();
    return;
};

const mailVálido = mail => {
  return /^[^\s@]+@[^\s@)]+\.[^\s@]+$/.test(mail); //expresión regular
};
if (!mailVálido(mail.value)) {
    mail.classList.add('is-invalid');
    errorMail.classList.add('own');
    mail.focus();
    return;
};

const temaVálido = tema => {
    return /^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/.test(tema);
};

if (!temaVálido(tema.value)) {
    tema.classList.add('is-invalid');
    errorTema.classList.add('own');
    tema.focus();
    return;
};

setTimeout(() => {
    location.reload();
}, 3000);

  //inserto el valor total en el html 
  // document.getElementById('totPag').innerHtml = totalAPagar;
  return document.getElementById('miBoton').innerHTML = '<p style= "font-size: 13px !important; color: aqua; text-align: center" >Operación exitosa</p>';
};

var x = document.getElementById('miBoton');
x.addEventListener('click', validarForm);

